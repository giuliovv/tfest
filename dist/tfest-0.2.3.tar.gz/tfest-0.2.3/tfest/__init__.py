from tfest.tfest import tfest

__version__ = '0.2.3'
__author__ = 'Giulio Vaccari'
__email__ = 'io@giuliovaccari.it'
__license__ = 'MIT'
__url__ = 'github.com/giuliovv/tfest'
